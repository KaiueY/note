const config = {
    database:{
        DATABASE:'noteBook',
        USERNAME:'root',
        PASSWORD:'root',
        PORT:'3306',
        HOST:'localhost'
    }
}
module.exports = config